// - Abre una nueva ventana "about:blank" en Google Chrome

// - Abre la consola de desarrollador de Google Chrome (F12)

// - Pregunta al usuario cuál es su edad y almacénala en una variable llamada edad


const edad = prompt("¿Cual es tu edad?");