
let result = 1;
let n = 10;

for (let i = 1; i <= n; i++) {
    result *= i;
}

console.log(result);