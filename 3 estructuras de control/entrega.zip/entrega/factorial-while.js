
let i = 1;
let n = 10;
let result = 1;


while ( i <= n){
    result *= i;
    i++ 
}

console.log(result);
