
let result = 1;
let i = 1;
let n = 10;


while (true) {
    if (i <= n) {
        result *= i;
        i++;
    }
    else {
        break;
    }
} 
    
console.log(result); 