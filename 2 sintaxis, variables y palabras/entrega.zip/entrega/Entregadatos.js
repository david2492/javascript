const datos =  {
    nombre: "Jonathan Rodriguez",
    edad: 30,
    eresDesarrollador: true,
    fecNacimiento: "Abril 04 92",
    libroFavorito: {
        titulo: "Cien Años de Soledad",
        autor: "Gabriel Garcia Marquez",
        fecha: "Junio 05 67",
        url: `https://www.secst.cl/upfiles/documentos/19072016_1207am_578dc39115fe9.pdf`,
    }
};

console.log(datos);